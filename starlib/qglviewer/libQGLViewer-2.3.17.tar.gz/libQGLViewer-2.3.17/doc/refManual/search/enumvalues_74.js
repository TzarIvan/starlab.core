var searchData=
[
  ['translate',['TRANSLATE',['../classQGLViewer.html#aded669cb17515ea2b5971496f9aef875abc6501410409b0638909b580970b35f7',1,'QGLViewer']]]
];
