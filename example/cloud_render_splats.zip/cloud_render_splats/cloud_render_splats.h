#pragma once
#include "CloudModel.h"
#include "interfaces/RenderPlugin.h"

class cloud_render_splats : public RenderPluginFactory{
    Q_OBJECT
    Q_INTERFACES(RenderPluginFactory)
public: 
    QString name() { return "Splats"; }
    QIcon icon(){ return QIcon(":/splats.png"); }
    bool isApplicable(Model* model){ return qobject_cast<CloudModel*>(model); }
    RenderPlugin* instance(Model* model);
};
