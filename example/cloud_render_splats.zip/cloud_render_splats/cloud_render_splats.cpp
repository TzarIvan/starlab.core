#include "cloud_render_splats.h"
#include <QVector>
#include <QVector3D>

//#include "KDTree.h"

#include <qgl.h>
#include <glu.h>

class SplatRenderer : public RenderPlugin{
private:
    CloudModel* cloud;
    QVector<QVector3D> normals; ///< normals
    float disksize;
    
public:
    SplatRenderer(Model* model) : RenderPlugin(model){
        cloud = qobject_cast<CloudModel*>(model);
    }
    void init(){
        normals.resize(cloud->points.size());
        /// @todo compute normals with KDTree
        for(int i=0; i<normals.size(); i++)
            normals[i] = QVector3D(0,0,1);
        /// Hard-coded disk size
        disksize = 0.01*cloud->getBoundingBox().size().length();
    }
    void render(){
        glEnable(GL_LIGHTING);
        glColor3f(.5,.5,.5);
        foreach(QVector4D v, cloud->points){
            glPushMatrix();
                glTranslatef(v.x(), v.y(), v.z());
                gluDisk(gluNewQuadric(), 0, disksize, 10, 1);
            glPopMatrix();
        }
    }
};

RenderPlugin* cloud_render_splats::instance(Model* model){
    return new SplatRenderer(model);
}

Q_EXPORT_PLUGIN(cloud_render_splats)
