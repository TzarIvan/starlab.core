#pragma once
#include "Widget.h"
#include "interfaces/ModePlugin.h"

class cloud_mode_selection : public ModePlugin{
    Q_OBJECT
    Q_INTERFACES(ModePlugin)
  
/// Functions part of the EditPlugin system
public:   
    virtual void createEdit(Document* /*doc*/, StarlabDrawArea* /*parent*/){ widget=new Widget(); }
    virtual void destroyEdit(Document* /*doc*/, StarlabDrawArea* /*parent*/){ delete widget; }    
};
