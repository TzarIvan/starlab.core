#include "cloud_mode_selection.h"
Q_EXPORT_PLUGIN(cloud_mode_selection)

