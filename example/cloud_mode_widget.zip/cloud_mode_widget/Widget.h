#pragma once
#include <QDockWidget>
#include <QDebug>

namespace Ui {
    class Widget;
}

class Widget : public QDockWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
   
private:
    Ui::Widget *ui;
};
